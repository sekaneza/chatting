<!--
Developer : R.K.D CHINTHAKA DESHAPRIYA
Blog : www.schoollk.blogspot.com
Email: chinthaka.fast@gmail.com
-->


<!-- Data Base Connection -->
<?php include('db.php'); ?>

<!-- Header Defualt Codes -->
<?php include('header.php');?> 

<body>
    <div class="container">
        <div class="masthead">
            <h3 class="text-muted">Dynamic Website</h3>
            <ul class="nav nav-justified">
                <li class="active"><a href="#">Home</a>
                </li>
                <li><a href="#">Projects</a>
                </li>
                <li><a href="#">Services</a>
                </li>
                <li><a href="#">Downloads</a>
                </li>
                <li><a href="#">About</a>
                </li>
                <li><a href="#">Contact</a>
                </li>
            </ul>
        </div>
        <hr>
    
        <div class="well">
            <div class="row">
 <!--php starts here-->
<?php				
				//$filter = isset($_POST['filter']) ? $_POST['filter'] : '';
				if(isset($_POST['filter']))
				{
					$filter = $_POST['filter'];
					$result = mysql_query("SELECT * FROM page where title like '%$filter%' or description like '%$filter%'");
				}
				else
				{
					$result = mysql_query("SELECT * FROM page");
                }
					
				if($result){				
				while($row=mysql_fetch_array($result)){
					
				$prodID = $row["id"];	
					echo '<div class="col-sm-6 col-md-4">';
                    echo '<div class="thumbnail">';
                    echo '<img src="'.$row['imgUrl'].'" alt="item1">';
                    echo '<div class="caption">';
                    echo '<h3>'.$row['title'].'</h3>';
                    echo '<p>'.$row['description'].'</p>';
                    echo  '<p><a href="page.php?prodid='.$prodID.'" class="btn btn-primary" role="button">View More</a> 
                            </p>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                    		
				}
				}
?>
 <!--php End here-->   
                
            </div>
        </div> 


<?php include('footer.php'); ?>