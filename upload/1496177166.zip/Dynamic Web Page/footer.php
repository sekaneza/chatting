        <!-- Site footer -->
        <div class="footer">
           <a href='http://www.schoollk.blogspot.com'><p>© SCHOOLLK BLOG</p></a> 
        </div>

    </div>
    <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="https://d33wubrfki0l68.cloudfront.net/js/e22b2f53de39b540c35079a7b7fcb51ca9727a7c/templates/examples/bootstrap/js/bootstrap.min.js"></script>


</body>

</html>