<!--
Developer : R.K.D CHINTHAKA DESHAPRIYA
Blog : www.schoollk.blogspot.com
Email: chinthaka.fast@gmail.com
-->

<?php
	include("db.php");
	
	$prodID = $_GET['prodid'];

	if(!empty($prodID)){
		$sqlSelectSpecProd = mysql_query("select * from page where id = '$prodID'") or die(mysql_error());
		$getProdInfo = mysql_fetch_array($sqlSelectSpecProd);
		$ptitle = $getProdInfo["title"];
		$pdes = $getProdInfo["description"];
		$pimg = $getProdInfo["imgUrl"];
				}
?>

<?php include('header.php'); ?>

<body>

    <div class="container">

        <div class="masthead">
            <h3 class="text-muted">Dynamic Website</h3>
            <ul class="nav nav-justified">
                <li class="active"><a href="index.php">Home</a>
                </li>
                <li><a href="#">Projects</a>
                </li>
                <li><a href="#">Services</a>
                </li>
                <li><a href="#">Downloads</a>
                </li>
                <li><a href="#">About</a>
                </li>
                <li><a href="#">Contact</a>
                </li>
            </ul>
        </div>
        <hr>
        <div class="well">
            <div class="row">
                <div class="col-sm-6 col-md-4">
                    <div class="thumbnail">
                        <img src="<?php echo $pimg; ?>" alt="">

                    </div>
                </div>
                <div class="col-sm-6 col-md-8">
                    <div class="thumbnail">

                        <div class="caption">
                            <h3><?php echo $ptitle; ?></h3> 
                            <p><?php echo $pdes; ?></p>
                            <p>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php include('footer.php'); ?>